var Employee = {
  Name: "Chirag Jobanputra",
  Age: 27,
  Salary: 25000,
  Address: {
    City: "Bangalore",
    State: "Karnataka",
    Pincode: 462030
  }
};

console.log(Employee);
console.log(Employee.Name + " " + Employee.Age + " " + Employee.Salary + " " + Employee.Address);
